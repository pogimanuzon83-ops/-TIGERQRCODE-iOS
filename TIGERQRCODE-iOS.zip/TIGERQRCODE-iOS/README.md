# TIGERQRCODE (iOS)

SwiftUI app — student ID QR codes, attendance scan, parent SMS alert, ID card save to Photos.

## Requirements

- **Mac** with **Xcode 15+**
- iOS **17+** deployment target (SwiftData)
- Physical iPhone for camera scan + SMS (Simulator limited)
- Apple ID (free) for device testing, or paid Developer account ($99/yr) for IPA distribution

## Create the Xcode project

1. Open **Xcode** → **File → New → Project**
2. **iOS → App** → Next
3. Product Name: `TIGERQRCODE`
4. Interface: **SwiftUI**, Language: **Swift**
5. Check **SwiftData** if shown (or we’ll use the models included)
6. Save the project, then **replace / add** the Swift files from the `TIGERQRCODE/` folder in this zip into your app target

### Add files

- Delete the default `ContentView.swift` if present
- Drag all files from `TIGERQRCODE/` into the Xcode project (copy items if needed)
- Ensure **Target Membership** = TIGERQRCODE

### Info.plist permissions

In target **Info** tab, add:

| Key | Value |
|-----|--------|
| Privacy - Camera Usage Description | Scan student QR codes for attendance |
| Privacy - Photo Library Additions Usage Description | Save student ID cards to Photos |
| Privacy - Photo Library Usage Description | Choose student photos for ID cards |
| Privacy - Contacts Usage Description | (optional) |

Or in `Info.plist`:

```xml
<key>NSCameraUsageDescription</key>
<string>Scan student QR codes for attendance</string>
<key>NSPhotoLibraryAddUsageDescription</key>
<string>Save student ID cards to Photos</string>
<key>NSPhotoLibraryUsageDescription</key>
<string>Choose student photos for ID cards</string>
```

## Run on device

1. Connect iPhone
2. Select your Team under **Signing & Capabilities**
3. Run ▶️

## Build IPA (for sharing)

1. **Product → Archive**
2. **Distribute App** → Ad Hoc / Development (needs devices registered) or App Store
3. Paid Apple Developer account required for most IPA install methods outside TestFlight

## Features (parity with Android)

- ID Card: school settings, photo, parent phone, QR generate, save ID card to Photos
- Students list
- Sections
- Scan QR → attendance + open Messages to parent
- Logs by date

## Note on SMS

iOS does **not** allow silent SMS send. The app opens the **Messages** composer with parent number + text (user taps Send). Same security rule as restricted Android SMS.
