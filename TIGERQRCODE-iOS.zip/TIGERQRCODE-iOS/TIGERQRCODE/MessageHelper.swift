import MessageUI
import UIKit

/// iOS cannot send SMS silently. Opens Messages with pre-filled body.
final class MessageHelper: NSObject, MFMessageComposeViewControllerDelegate {
    static let shared = MessageHelper()

    func presentAttendanceMessage(
        from presenter: UIViewController,
        phone: String?,
        studentName: String,
        time: String
    ) {
        guard let phone, phone.filter({ $0.isNumber || $0 == "+" }).count >= 10 else { return }
        guard MFMessageComposeViewController.canSendText() else { return }

        let hour = Calendar.current.component(.hour, from: Date())
        let greeting = hour < 12 ? "Good morning" : "Good afternoon"
        let school = SchoolSettings.schoolName
        let supervisor = SchoolSettings.supervisor
        var body = "\(greeting)! This is to inform you that \(studentName) has successfully timed in at \(time.replacingOccurrences(of: " ", with: "").lowercased()) today at \(school)"
        if !supervisor.isEmpty {
            body += " under the supervision of \(supervisor)"
        }
        body += "."

        let vc = MFMessageComposeViewController()
        vc.messageComposeDelegate = self
        vc.recipients = [phone]
        vc.body = body
        presenter.present(vc, animated: true)
    }

    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
        controller.dismiss(animated: true)
    }
}

enum MessagePresenter {
    static func topViewController() -> UIViewController? {
        let scene = UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .first { $0.activationState == .foregroundActive }
        var vc = scene?.windows.first { $0.isKeyWindow }?.rootViewController
        while let presented = vc?.presentedViewController { vc = presented }
        return vc
    }
}
