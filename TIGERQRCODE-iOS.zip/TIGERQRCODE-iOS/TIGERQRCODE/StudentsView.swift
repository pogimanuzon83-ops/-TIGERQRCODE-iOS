import SwiftUI
import SwiftData

struct StudentsView: View {
    @Environment(\.modelContext) private var modelContext
    @Query(sort: \Student.name) private var students: [Student]
    @State private var search = ""

    var filtered: [Student] {
        if search.isEmpty { return students }
        return students.filter {
            $0.name.localizedCaseInsensitiveContains(search) ||
            $0.lrn.localizedCaseInsensitiveContains(search)
        }
    }

    var body: some View {
        NavigationStack {
            VStack {
                LiveClockHeader().padding(.horizontal)
                TextField("Search name or LRN", text: $search)
                    .textFieldStyle(.roundedBorder)
                    .padding(.horizontal)
                List {
                    ForEach(filtered, id: \.id) { s in
                        HStack {
                            if let data = s.photoData, let img = UIImage(data: data) {
                                Image(uiImage: img)
                                    .resizable()
                                    .scaledToFill()
                                    .frame(width: 44, height: 52)
                                    .clipShape(RoundedRectangle(cornerRadius: 6))
                            } else {
                                Text("👤").frame(width: 44, height: 52)
                            }
                            VStack(alignment: .leading) {
                                Text(s.name).font(.headline)
                                Text("\(s.section) · \(s.strand) · LRN: \(s.lrn)")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                if let p = s.parentPhone, !p.isEmpty {
                                    Text("📱 \(p)").font(.caption2).foregroundStyle(.secondary)
                                }
                            }
                        }
                    }
                    .onDelete { indexSet in
                        for i in indexSet {
                            modelContext.delete(filtered[i])
                        }
                    }
                }
            }
            .navigationTitle("Students")
        }
    }
}
