import Foundation
import SwiftData

@Model
final class Student {
    @Attribute(.unique) var id: String
    var name: String
    var section: String
    var strand: String
    var lrn: String
    var parentPhone: String?
    var photoData: Data?
    var createdAt: Date

    init(
        id: String = UUID().uuidString,
        name: String,
        section: String,
        strand: String,
        lrn: String,
        parentPhone: String? = nil,
        photoData: Data? = nil,
        createdAt: Date = Date()
    ) {
        self.id = id
        self.name = name
        self.section = section
        self.strand = strand
        self.lrn = lrn
        self.parentPhone = parentPhone
        self.photoData = photoData
        self.createdAt = createdAt
    }
}

@Model
final class SectionEntity {
    @Attribute(.unique) var name: String
    init(name: String) { self.name = name }
}

@Model
final class AttendanceRecord {
    @Attribute(.unique) var id: String
    var studentId: String
    var name: String
    var section: String
    var strand: String
    var lrn: String
    var photoData: Data?
    var date: String   // yyyy-MM-dd
    var time: String
    var timestamp: Date

    init(
        id: String = UUID().uuidString,
        studentId: String,
        name: String,
        section: String,
        strand: String,
        lrn: String,
        photoData: Data? = nil,
        date: String,
        time: String,
        timestamp: Date = Date()
    ) {
        self.id = id
        self.studentId = studentId
        self.name = name
        self.section = section
        self.strand = strand
        self.lrn = lrn
        self.photoData = photoData
        self.date = date
        self.time = time
        self.timestamp = timestamp
    }
}

struct StudentQRPayload: Codable {
    var type: String = "STUDENT"
    var name: String
    var section: String
    var strand: String
    var lrn: String
    var parentPhone: String?
}

enum AppDate {
    static func today() -> String {
        let f = DateFormatter()
        f.dateFormat = "yyyy-MM-dd"
        return f.string(from: Date())
    }
    static func nowTime() -> String {
        let f = DateFormatter()
        f.dateFormat = "hh:mm:ss a"
        return f.string(from: Date())
    }
}
