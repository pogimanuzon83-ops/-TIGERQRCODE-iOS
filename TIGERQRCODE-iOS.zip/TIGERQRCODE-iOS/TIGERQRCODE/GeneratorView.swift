import SwiftUI
import Photos
import PhotosUI

struct GeneratorView: View {
    @Environment(\.modelContext) private var modelContext
    @Query(sort: \SectionEntity.name) private var sections: [SectionEntity]

    @State private var schoolName = SchoolSettings.schoolName
    @State private var schoolSub = SchoolSettings.schoolSub
    @State private var supervisor = SchoolSettings.supervisor
    @State private var name = ""
    @State private var section = ""
    @State private var strand = ""
    @State private var lrn = ""
    @State private var parentPhone = ""
    @State private var photoItem: PhotosPickerItem?
    @State private var photoImage: UIImage?
    @State private var qrImage: UIImage?
    @State private var message: String?
    @State private var showPreview = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    LiveClockHeader()

                    Text("ID Card Generator")
                        .font(.title2.bold())
                        .foregroundStyle(Color(red: 0.05, green: 0.28, blue: 0.63))

                    GroupBox("School Settings") {
                        TextField("School Name", text: $schoolName)
                        TextField("Subtitle / Campus", text: $schoolSub)
                        TextField("Supervisor (for SMS)", text: $supervisor)
                    }

                    GroupBox("Student Information") {
                        HStack {
                            if let photoImage {
                                Image(uiImage: photoImage)
                                    .resizable()
                                    .scaledToFill()
                                    .frame(width: 72, height: 88)
                                    .clipShape(RoundedRectangle(cornerRadius: 8))
                            } else {
                                RoundedRectangle(cornerRadius: 8)
                                    .fill(Color.gray.opacity(0.2))
                                    .frame(width: 72, height: 88)
                                    .overlay(Text("👤").font(.largeTitle))
                            }
                            PhotosPicker(selection: $photoItem, matching: .images) {
                                Text("Add Photo")
                            }
                            .buttonStyle(.borderedProminent)
                        }
                        TextField("Full Name", text: $name)
                        TextField("Section", text: $section)
                        if !sections.isEmpty {
                            ScrollView(.horizontal, showsIndicators: false) {
                                HStack {
                                    ForEach(sections, id: \.name) { s in
                                        Button(s.name) { section = s.name }
                                            .buttonStyle(.bordered)
                                    }
                                }
                            }
                        }
                        TextField("Strand (STEM, ABM, ICT…)", text: $strand)
                        TextField("LRN", text: $lrn)
                        TextField("Parent Cellphone", text: $parentPhone)
                            .keyboardType(.phonePad)

                        HStack {
                            Button("Generate QR") { generate() }
                                .buttonStyle(.borderedProminent)
                            Button("Save Student") { generateAndSave() }
                                .buttonStyle(.borderedProminent)
                                .tint(.green)
                        }
                    }

                    if let message {
                        Text(message).foregroundStyle(.blue)
                    }

                    if showPreview, let qrImage {
                        GroupBox("Preview") {
                            IDCardPreview(
                                schoolName: schoolName,
                                schoolSub: schoolSub,
                                name: name,
                                section: section,
                                strand: strand,
                                lrn: lrn,
                                parentPhone: parentPhone,
                                photo: photoImage,
                                qr: qrImage
                            )
                            Text("ID card ready — QR is on the card")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                            Button("Save ID Card to Photos") { saveCardToPhotos() }
                                .buttonStyle(.borderedProminent)
                                .frame(maxWidth: .infinity)
                        }
                    }
                }
                .padding()
            }
            .navigationBarTitleDisplayMode(.inline)
            .onChange(of: photoItem) { _, item in
                Task {
                    if let data = try? await item?.loadTransferable(type: Data.self),
                       let img = UIImage(data: data) {
                        photoImage = img
                    }
                }
            }
        }
    }

    private func generate() {
        guard !name.isEmpty, !section.isEmpty, !strand.isEmpty, !lrn.isEmpty else {
            message = "Please fill Name, Section, Strand, and LRN"
            return
        }
        guard photoImage != nil else {
            message = "Please add a student photo first"
            return
        }
        guard !parentPhone.isEmpty else {
            message = "Please enter Parent Cellphone"
            return
        }
        SchoolSettings.schoolName = schoolName
        SchoolSettings.schoolSub = schoolSub
        SchoolSettings.supervisor = supervisor

        let payload = StudentQRPayload(
            name: name.trimmingCharacters(in: .whitespaces),
            section: section.trimmingCharacters(in: .whitespaces),
            strand: strand.trimmingCharacters(in: .whitespaces),
            lrn: lrn.trimmingCharacters(in: .whitespaces),
            parentPhone: parentPhone.trimmingCharacters(in: .whitespaces)
        )
        guard let json = QRCodeHelper.payloadJSON(payload),
              let img = QRCodeHelper.generate(from: json) else {
            message = "Failed to generate QR"
            return
        }
        qrImage = img
        showPreview = true
        saveStudentToDB()
        message = "QR ready — student & photo saved"
    }

    private func generateAndSave() {
        generate()
        if showPreview {
            message = "Student saved: \(name)"
        }
    }

    private func saveStudentToDB() {
        let lrnTrim = lrn.trimmingCharacters(in: .whitespaces)
        let descriptor = FetchDescriptor<Student>(predicate: #Predicate { $0.lrn == lrnTrim })
        let existing = try? modelContext.fetch(descriptor).first
        let photoData = photoImage?.jpegData(compressionQuality: 0.85)
        if let existing {
            existing.name = name.trimmingCharacters(in: .whitespaces)
            existing.section = section.trimmingCharacters(in: .whitespaces)
            existing.strand = strand.trimmingCharacters(in: .whitespaces)
            existing.parentPhone = parentPhone.trimmingCharacters(in: .whitespaces)
            existing.photoData = photoData ?? existing.photoData
        } else {
            let s = Student(
                name: name.trimmingCharacters(in: .whitespaces),
                section: section.trimmingCharacters(in: .whitespaces),
                strand: strand.trimmingCharacters(in: .whitespaces),
                lrn: lrnTrim,
                parentPhone: parentPhone.trimmingCharacters(in: .whitespaces),
                photoData: photoData
            )
            modelContext.insert(s)
        }
        try? modelContext.save()
    }

    private func saveCardToPhotos() {
        guard let qrImage, let photoImage else { return }
        let card = IDCardRenderer.render(
            schoolName: schoolName,
            schoolSub: schoolSub,
            studentName: name,
            section: section,
            strand: strand,
            lrn: lrn,
            parentPhone: parentPhone,
            photo: photoImage,
            qr: qrImage
        )
        UIImageWriteToSavedPhotosAlbum(card, nil, nil, nil)
        message = "ID card saved to Photos"
    }
}

struct IDCardPreview: View {
    let schoolName, schoolSub, name, section, strand, lrn, parentPhone: String
    let photo: UIImage?
    let qr: UIImage

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            if let photo {
                Image(uiImage: photo)
                    .resizable()
                    .scaledToFill()
                    .frame(width: 56, height: 68)
                    .clipShape(RoundedRectangle(cornerRadius: 6))
            }
            VStack(alignment: .leading, spacing: 4) {
                Text(schoolName).font(.caption.bold()).foregroundStyle(.white)
                Text(name).font(.subheadline.bold()).foregroundStyle(.white)
                Text("Section: \(section)").font(.caption2).foregroundStyle(.white.opacity(0.9))
                Text("LRN: \(lrn)").font(.caption2).foregroundStyle(.white.opacity(0.9))
            }
            Spacer()
            Image(uiImage: qr)
                .resizable()
                .interpolation(.none)
                .frame(width: 64, height: 64)
                .background(Color.white)
                .cornerRadius(4)
        }
        .padding(12)
        .background(
            LinearGradient(colors: [Color(red: 0.05, green: 0.28, blue: 0.63), Color(red: 0.08, green: 0.4, blue: 0.75)], startPoint: .topLeading, endPoint: .bottomTrailing)
        )
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
}

struct LiveClockHeader: View {
    @State private var now = Date()
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()

    var body: some View {
        HStack {
            VStack(alignment: .leading) {
                Text("TIGERQRCODE").font(.headline).foregroundStyle(.white)
                Text(now.formatted(date: .abbreviated, time: .omitted))
                    .font(.caption).foregroundStyle(.white.opacity(0.85))
            }
            Spacer()
            Text(now.formatted(date: .omitted, time: .standard))
                .font(.title3.bold()).foregroundStyle(.white)
        }
        .padding()
        .background(Color(red: 0.05, green: 0.28, blue: 0.63))
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .onReceive(timer) { now = $0 }
    }
}
