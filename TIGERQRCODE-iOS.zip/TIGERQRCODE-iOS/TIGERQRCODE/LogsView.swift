import SwiftUI
import SwiftData

struct LogsView: View {
    @Environment(\.modelContext) private var modelContext
    @Query(sort: \AttendanceRecord.timestamp) private var allRecords: [AttendanceRecord]
    @Query private var students: [Student]
    @Query private var sections: [SectionEntity]
    @State private var dateStr = AppDate.today()

    var logs: [AttendanceRecord] {
        allRecords.filter { $0.date == dateStr }.sorted { $0.timestamp < $1.timestamp }
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 12) {
                LiveClockHeader().padding(.horizontal)

                Text("Attendance Logs")
                    .font(.title2.bold())
                    .foregroundStyle(Color(red: 0.05, green: 0.28, blue: 0.63))
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal)

                HStack {
                    StatBox(value: "\(logs.count)", label: "Total Today")
                    StatBox(value: "\(sections.count)", label: "Sections")
                    StatBox(value: "\(students.count)", label: "Registered")
                }
                .padding(.horizontal)

                TextField("Date (yyyy-MM-dd)", text: $dateStr)
                    .textFieldStyle(.roundedBorder)
                    .padding(.horizontal)

                HStack {
                    Button("Today") { dateStr = AppDate.today() }
                        .buttonStyle(.bordered)
                    Button("Clear Day", role: .destructive) {
                        for r in logs { modelContext.delete(r) }
                    }
                    .buttonStyle(.bordered)
                }

                List(logs, id: \.id) { record in
                    HStack {
                        if let data = record.photoData, let img = UIImage(data: data) {
                            Image(uiImage: img)
                                .resizable()
                                .scaledToFill()
                                .frame(width: 40, height: 48)
                                .clipShape(RoundedRectangle(cornerRadius: 4))
                        } else {
                            Text("👤")
                        }
                        VStack(alignment: .leading) {
                            Text(record.name).font(.headline)
                            Text("\(record.section) · LRN: \(record.lrn)")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                        Text(record.time)
                            .font(.caption.bold())
                            .foregroundStyle(.green)
                    }
                }
            }
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

struct StatBox: View {
    let value: String
    let label: String
    var body: some View {
        VStack {
            Text(value).font(.title2.bold())
            Text(label).font(.caption2).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(8)
        .background(Color.gray.opacity(0.12))
        .clipShape(RoundedRectangle(cornerRadius: 10))
    }
}
