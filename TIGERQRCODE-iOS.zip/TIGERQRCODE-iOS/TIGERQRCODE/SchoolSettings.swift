import Foundation

enum SchoolSettings {
    private static let defaults = UserDefaults.standard

    static var schoolName: String {
        get { defaults.string(forKey: "schoolName") ?? "YOUR SCHOOL NAME" }
        set { defaults.set(newValue, forKey: "schoolName") }
    }
    static var schoolSub: String {
        get { defaults.string(forKey: "schoolSub") ?? "Campus / City" }
        set { defaults.set(newValue, forKey: "schoolSub") }
    }
    static var supervisor: String {
        get { defaults.string(forKey: "supervisor") ?? "" }
        set { defaults.set(newValue, forKey: "supervisor") }
    }
}
