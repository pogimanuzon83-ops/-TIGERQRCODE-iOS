import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            GeneratorView()
                .tabItem { Label("ID Card", systemImage: "person.crop.rectangle") }
            StudentsView()
                .tabItem { Label("Students", systemImage: "person.3") }
            SectionsView()
                .tabItem { Label("Sections", systemImage: "folder") }
            ScanView()
                .tabItem { Label("Scan", systemImage: "qrcode.viewfinder") }
            LogsView()
                .tabItem { Label("Logs", systemImage: "list.bullet.rectangle") }
        }
        .tint(Color(red: 0.08, green: 0.28, blue: 0.63))
    }
}

#Preview {
    ContentView()
}
