import SwiftUI
import SwiftData

struct SectionsView: View {
    @Environment(\.modelContext) private var modelContext
    @Query(sort: \SectionEntity.name) private var sections: [SectionEntity]
    @State private var newName = ""

    var body: some View {
        NavigationStack {
            VStack {
                LiveClockHeader().padding(.horizontal)
                HStack {
                    TextField("New section (e.g. 12-STEM-A)", text: $newName)
                        .textFieldStyle(.roundedBorder)
                    Button("Add") {
                        let t = newName.trimmingCharacters(in: .whitespaces)
                        guard !t.isEmpty else { return }
                        modelContext.insert(SectionEntity(name: t))
                        newName = ""
                    }
                    .buttonStyle(.borderedProminent)
                }
                .padding(.horizontal)
                List {
                    ForEach(sections, id: \.name) { s in
                        Text(s.name)
                    }
                    .onDelete { idx in
                        for i in idx { modelContext.delete(sections[i]) }
                    }
                }
            }
            .navigationTitle("Sections")
        }
    }
}
