import SwiftUI
import SwiftData
import AVFoundation

struct ScanView: View {
    @Environment(\.modelContext) private var modelContext
    @State private var lastScan = Date.distantPast
    @State private var resultTitle: String?
    @State private var resultSubtitle: String?
    @State private var resultStudent: Student?
    @State private var isSuccess = false
    @State private var scanning = true

    var body: some View {
        NavigationStack {
            VStack(spacing: 12) {
                LiveClockHeader()
                Text("QR Attendance Scanner")
                    .font(.title2.bold())
                    .foregroundStyle(Color(red: 0.05, green: 0.28, blue: 0.63))
                    .frame(maxWidth: .infinity, alignment: .leading)

                Text("Point camera at student QR. Attendance is recorded; Messages opens for parent alert.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)

                QRScannerRepresentable { code in
                    handleScan(code)
                }
                .frame(height: 280)
                .clipShape(RoundedRectangle(cornerRadius: 12))

                if let resultTitle {
                    VStack(spacing: 8) {
                        if let data = resultStudent?.photoData, let img = UIImage(data: data) {
                            Image(uiImage: img)
                                .resizable()
                                .scaledToFill()
                                .frame(width: 90, height: 108)
                                .clipShape(RoundedRectangle(cornerRadius: 10))
                        } else {
                            Text("👤").font(.system(size: 48))
                        }
                        Text(resultTitle)
                            .font(.headline)
                            .foregroundStyle(isSuccess ? .green : .orange)
                        if let resultSubtitle {
                            Text(resultSubtitle)
                                .multilineTextAlignment(.center)
                                .font(.subheadline)
                        }
                    }
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(isSuccess ? Color.green.opacity(0.12) : Color.orange.opacity(0.12))
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                }
                Spacer()
            }
            .padding()
            .navigationBarTitleDisplayMode(.inline)
        }
    }

    private func handleScan(_ raw: String) {
        let now = Date()
        guard now.timeIntervalSince(lastScan) > 3 else { return }
        lastScan = now

        guard let payload = QRCodeHelper.parsePayload(raw) else {
            resultTitle = "Invalid QR"
            resultSubtitle = "Not a student ID"
            isSuccess = false
            resultStudent = nil
            return
        }

        let lrn = payload.lrn.trimmingCharacters(in: .whitespaces)
        let descriptor = FetchDescriptor<Student>(predicate: #Predicate { $0.lrn == lrn })
        var student = try? modelContext.fetch(descriptor).first

        if student == nil {
            student = Student(
                name: payload.name.isEmpty ? "Unknown" : payload.name,
                section: payload.section,
                strand: payload.strand,
                lrn: lrn,
                parentPhone: payload.parentPhone
            )
            // Don't insert transient scan-only without photo unless needed
        }

        let today = AppDate.today()
        let attDesc = FetchDescriptor<AttendanceRecord>(
            predicate: #Predicate { $0.lrn == lrn && $0.date == today }
        )
        if let existing = try? modelContext.fetch(attDesc).first {
            resultStudent = student
            resultTitle = "Already: \(student?.name ?? payload.name)"
            resultSubtitle = "Already recorded — \(existing.time)"
            isSuccess = false
            return
        }

        let time = AppDate.nowTime()
        let record = AttendanceRecord(
            studentId: student?.id ?? "qr-\(lrn)",
            name: student?.name ?? payload.name,
            section: student?.section ?? payload.section,
            strand: student?.strand ?? payload.strand,
            lrn: lrn,
            photoData: student?.photoData,
            date: today,
            time: time
        )
        modelContext.insert(record)
        try? modelContext.save()

        resultStudent = student
        resultTitle = "OK: \(record.name)"
        resultSubtitle = "Time In: \(time)"
        isSuccess = true

        // Open Messages for parent (iOS cannot silent-send SMS)
        let phone = student?.parentPhone ?? payload.parentPhone
        if let vc = MessagePresenter.topViewController() {
            MessageHelper.shared.presentAttendanceMessage(
                from: vc,
                phone: phone,
                studentName: record.name,
                time: time
            )
        }
    }
}

/// UIKit camera QR scanner
struct QRScannerRepresentable: UIViewControllerRepresentable {
    var onCode: (String) -> Void

    func makeUIViewController(context: Context) -> ScannerVC {
        let vc = ScannerVC()
        vc.onCode = onCode
        return vc
    }

    func updateUIViewController(_ uiViewController: ScannerVC, context: Context) {}
}

final class ScannerVC: UIViewController, AVCaptureMetadataOutputObjectsDelegate {
    var onCode: ((String) -> Void)?
    private let session = AVCaptureSession()
    private var preview: AVCaptureVideoPreviewLayer?

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized: setup()
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { [weak self] ok in
                if ok { DispatchQueue.main.async { self?.setup() } }
            }
        default: break
        }
    }

    private func setup() {
        guard let device = AVCaptureDevice.default(for: .video),
              let input = try? AVCaptureDeviceInput(device: device),
              session.canAddInput(input) else { return }
        session.addInput(input)
        let output = AVCaptureMetadataOutput()
        guard session.canAddOutput(output) else { return }
        session.addOutput(output)
        output.setMetadataObjectsDelegate(self, queue: .main)
        output.metadataObjectTypes = [.qr]
        let layer = AVCaptureVideoPreviewLayer(session: session)
        layer.videoGravity = .resizeAspectFill
        layer.frame = view.bounds
        view.layer.addSublayer(layer)
        preview = layer
        DispatchQueue.global(qos: .userInitiated).async { self.session.startRunning() }
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        preview?.frame = view.bounds
    }

    func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
        guard let obj = metadataObjects.first as? AVMetadataMachineReadableCodeObject,
              obj.type == .qr,
              let val = obj.stringValue else { return }
        onCode?(val)
    }
}
