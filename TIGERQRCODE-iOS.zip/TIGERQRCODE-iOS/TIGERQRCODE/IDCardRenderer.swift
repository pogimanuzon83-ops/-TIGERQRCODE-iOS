import UIKit

enum IDCardRenderer {
    static func render(
        schoolName: String,
        schoolSub: String,
        studentName: String,
        section: String,
        strand: String,
        lrn: String,
        parentPhone: String?,
        photo: UIImage?,
        qr: UIImage,
        size: CGSize = CGSize(width: 1080, height: 640)
    ) -> UIImage {
        let format = UIGraphicsImageRendererFormat()
        format.scale = 1
        let renderer = UIGraphicsImageRenderer(size: size, format: format)
        return renderer.image { ctx in
            let cg = ctx.cgContext
            let colors = [
                UIColor(red: 0.05, green: 0.28, blue: 0.63, alpha: 1).cgColor,
                UIColor(red: 0.08, green: 0.40, blue: 0.75, alpha: 1).cgColor
            ]
            if let gradient = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: colors as CFArray, locations: [0, 1]) {
                cg.drawLinearGradient(gradient, start: .zero, end: CGPoint(x: size.width, y: size.height), options: [])
            }

            let white = UIColor.white
            let titleFont = UIFont.boldSystemFont(ofSize: 42)
            let subFont = UIFont.systemFont(ofSize: 28)
            let nameFont = UIFont.boldSystemFont(ofSize: 40)
            let infoFont = UIFont.systemFont(ofSize: 30)

            (schoolName as NSString).draw(at: CGPoint(x: 40, y: 30), withAttributes: [.font: titleFont, .foregroundColor: white])
            (schoolSub as NSString).draw(at: CGPoint(x: 40, y: 80), withAttributes: [.font: subFont, .foregroundColor: white.withAlphaComponent(0.85)])

            let photoRect = CGRect(x: 40, y: 140, width: 200, height: 240)
            UIColor.white.withAlphaComponent(0.2).setFill()
            UIBezierPath(roundedRect: photoRect, cornerRadius: 16).fill()
            if let photo {
                photo.draw(in: photoRect)
            }

            var y: CGFloat = 170
            let textX: CGFloat = 260
            (studentName as NSString).draw(at: CGPoint(x: textX, y: y), withAttributes: [.font: nameFont, .foregroundColor: white])
            y += 60
            ("Section: \(section)" as NSString).draw(at: CGPoint(x: textX, y: y), withAttributes: [.font: infoFont, .foregroundColor: white])
            y += 44
            ("Strand: \(strand)" as NSString).draw(at: CGPoint(x: textX, y: y), withAttributes: [.font: infoFont, .foregroundColor: white])
            y += 44
            ("LRN: \(lrn)" as NSString).draw(at: CGPoint(x: textX, y: y), withAttributes: [.font: infoFont, .foregroundColor: white])
            if let parentPhone, !parentPhone.isEmpty {
                y += 44
                ("Parent: \(parentPhone)" as NSString).draw(at: CGPoint(x: textX, y: y), withAttributes: [.font: infoFont, .foregroundColor: white])
            }

            let qrSize: CGFloat = 220
            let qrOrigin = CGPoint(x: size.width - qrSize - 50, y: 150)
            UIColor.white.setFill()
            UIBezierPath(roundedRect: CGRect(x: qrOrigin.x - 10, y: qrOrigin.y - 10, width: qrSize + 20, height: qrSize + 20), cornerRadius: 12).fill()
            qr.draw(in: CGRect(origin: qrOrigin, size: CGSize(width: qrSize, height: qrSize)))

            ("TIGERQRCODE — Student ID" as NSString).draw(
                at: CGPoint(x: 40, y: size.height - 50),
                withAttributes: [.font: UIFont.systemFont(ofSize: 24), .foregroundColor: white.withAlphaComponent(0.7)]
            )
        }
    }
}
