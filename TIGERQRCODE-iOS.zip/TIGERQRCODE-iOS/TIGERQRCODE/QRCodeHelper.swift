import UIKit
import CoreImage.CIFilterBuiltins

enum QRCodeHelper {
    static func generate(from string: String, size: CGFloat = 512) -> UIImage? {
        let context = CIContext()
        let filter = CIFilter.qrCodeGenerator()
        filter.message = Data(string.utf8)
        filter.correctionLevel = "M"
        guard let output = filter.outputImage else { return nil }
        let scale = size / output.extent.width
        let scaled = output.transformed(by: CGAffineTransform(scaleX: scale, y: scale))
        guard let cg = context.createCGImage(scaled, from: scaled.extent) else { return nil }
        return UIImage(cgImage: cg)
    }

    static func payloadJSON(_ payload: StudentQRPayload) -> String? {
        let enc = JSONEncoder()
        guard let data = try? enc.encode(payload) else { return nil }
        return String(data: data, encoding: .utf8)
    }

    static func parsePayload(_ raw: String) -> StudentQRPayload? {
        if let data = raw.data(using: .utf8),
           let p = try? JSONDecoder().decode(StudentQRPayload.self, from: data),
           !p.lrn.isEmpty {
            return p
        }
        // Legacy plain-text lines
        var name = "", section = "", strand = "", lrn = ""
        for line in raw.split(separator: "\n") {
            let s = String(line)
            if s.hasPrefix("Name:") { name = s.replacingOccurrences(of: "Name:", with: "").trimmingCharacters(in: .whitespaces) }
            if s.hasPrefix("Section:") { section = s.replacingOccurrences(of: "Section:", with: "").trimmingCharacters(in: .whitespaces) }
            if s.hasPrefix("Strand:") { strand = s.replacingOccurrences(of: "Strand:", with: "").trimmingCharacters(in: .whitespaces) }
            if s.hasPrefix("LRN:") { lrn = s.replacingOccurrences(of: "LRN:", with: "").trimmingCharacters(in: .whitespaces) }
        }
        guard !lrn.isEmpty else { return nil }
        return StudentQRPayload(name: name, section: section, strand: strand, lrn: lrn, parentPhone: nil)
    }
}
