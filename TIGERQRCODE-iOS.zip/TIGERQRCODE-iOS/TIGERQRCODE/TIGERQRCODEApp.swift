import SwiftUI
import SwiftData

@main
struct TIGERQRCODEApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
        .modelContainer(for: [Student.self, SectionEntity.self, AttendanceRecord.self])
    }
}
